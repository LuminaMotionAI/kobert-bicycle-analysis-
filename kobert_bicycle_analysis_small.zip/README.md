# KoBERT 자전거 데이터 분석 패키지

이 저장소는 한국어 자전거 리뷰 데이터에 대한 종합적인 분석 도구를 제공합니다.

## 주요 기능

- **감성 분석**: KoBERT를 활용한 자전거 리뷰 감성 분석
- **토픽 모델링**: LDA를 활용한 리뷰 데이터 토픽 추출
- **키워드 네트워크 분석**: 키워드 간 관계 및 연관성 시각화
- **페르소나 분석**: 고객 세그먼트 및 마케팅 페르소나 도출
- **대시보드**: Streamlit 기반 데이터 시각화 대시보드

## 시작하기

### 필수 요구사항

- Python 3.7 이상
- Java 환경 (KoNLPy 사용을 위함)
- 필요한 패키지들 (requirements.txt 참조)

### 설치

```bash
# 저장소 복제
git clone https://github.com/yourusername/kobert-bicycle-analysis.git
cd kobert-bicycle-analysis

# 필요한 패키지 설치
pip install -r requirements.txt
```

## 전체 데이터셋 및 결과물

전체 데이터셋과 분석 결과물은 용량이 크기 때문에 GitHub Releases를 통해 제공됩니다:

1. [완전한 분석 결과 다운로드](https://github.com/yourusername/kobert-bicycle-analysis/releases/download/v1.0.0/kobert_bicycle_analysis_github.zip)

이 파일에는 다음이 포함되어 있습니다:
- 전체 리뷰 데이터셋
- EDA 결과
- 토픽 모델링 결과
- 키워드 네트워크 분석 결과
- 페르소나 분석 결과

## 실행 방법

### 데이터 분석 전체 프로세스

```bash
# 텍스트 마이닝 실행
python run_text_mining.py

# KoBERT 감성 분석 실행
python run_kobert_sentiment.py

# 토픽 모델링 실행
python run_lda_topic_modeling.py

# 키워드 네트워크 분석 실행
python run_keyword_network_analysis.py

# 페르소나 분석 실행
python run_persona_analysis.py
```

### 대시보드 실행

```bash
python run_dashboard.py
```

## 프로젝트 구조

```
kobert-bicycle-analysis/
│
├── data/                  # 데이터 폴더
│   └── review_data.csv    # 자전거 리뷰 데이터
│
├── output/                # 출력 폴더 (Releases에서 다운로드)
│   ├── eda_results/       # EDA 결과
│   ├── topic_modeling/    # 토픽 모델링 결과
│   ├── keyword_network/   # 키워드 네트워크 결과
│   └── persona/           # 페르소나 분석 결과
│
├── *.py                   # 분석 스크립트 파일들
└── requirements.txt       # 필요 패키지 목록
```

## 라이센스

이 프로젝트는 MIT 라이센스 하에 배포됩니다. 